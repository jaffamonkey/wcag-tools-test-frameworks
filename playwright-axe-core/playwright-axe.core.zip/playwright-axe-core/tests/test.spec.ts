import { test, Page } from "@playwright/test";
import fs from "fs";
import path from "path";
import {
  runAccessibilityCheck,
  closeAccessibilityChecker,
} from "../utils/accessibility";

// Read urls.txt from the same folder as this spec
const urlsFilePath = path.join(__dirname, "urls.txt");

function getPageReference(url: string): string {
  const pathname = new URL(url).pathname;
  const segments = pathname.split("/").filter(Boolean);

  // Use the last non-empty path segment
  return segments[segments.length - 1] ?? "UnknownPage";
}

function loadUrls(filePath: string): string[] {
  return fs
    .readFileSync(filePath, "utf8")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
}

const urls: string[] = loadUrls(urlsFilePath);

test.describe("Website Check (WCAG 2.2 AA)", () => {
  test.afterAll(async () => {
    await closeAccessibilityChecker();
  });

  test.beforeEach(async () => {
    test.setTimeout(300000);
  });

  for (const url of urls) {
    const pageRef = getPageReference(url);

    test(pageRef, async ({ page }: { page: Page }) => {
      await page.goto(url);
      await runAccessibilityCheck(page, pageRef, {
        testInfo: test.info(),
      });
    });
  }
});