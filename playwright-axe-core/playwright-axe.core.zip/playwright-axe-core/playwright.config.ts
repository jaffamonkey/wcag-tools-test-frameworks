import { defineConfig, devices } from '@playwright/test';

const headless = process.env.HEADLESS
  ? ['true', '1', 'yes', 'on'].includes(process.env.HEADLESS.toLowerCase())
  : true; // default: headed (not headless)

export default defineConfig({
  testDir: './tests',
  globalTimeout: 600000, // 10 minutes
  fullyParallel: false,
  reporter: [
    ['html', {
      open: 'never',
      outputFolder: 'my-custom-report-folder'
    }]
  ],

  use: {
    headless: true,
    // extraHTTPHeaders: {
    //   'header name': 'header value',
    // },
    viewport: { width: 1600, height: 1000 },
  },

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    // {
    //   name: 'Mobile Chrome',
    //   use: {
    //     browserName: 'chromium',
    //     ...devices['Pixel 5'],
    //   },
    // },
    // {
    //   name: 'Mobile Safari',
    //   use: {
    //     ...devices['iPhone 13'],
    //   },
    // },
  ],
});

