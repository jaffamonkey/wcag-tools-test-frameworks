# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: test.spec.ts >> Website Check (WCAG 2.2 AA) >> Revolution
- Location: tests/test.spec.ts:42:9

# Error details

```
Error: 
1) [MODERATE] html
Rule: landmark-one-main
Description: Ensure the document has a main landmark
Help: Document should have one main landmark
Help URL: https://dequeuniversity.com/rules/axe/4.11/landmark-one-main?application=playwright


2) [MODERATE] html
Rule: page-has-heading-one
Description: Ensure that the page, or at least one of its frames contains a level-one heading
Help: Page should contain a level-one heading
Help URL: https://dequeuniversity.com/rules/axe/4.11/page-has-heading-one?application=playwright


3) [MODERATE] body > center:nth-child(1) > table[cellspacing="0"][cellpadding="0"] > tbody > tr > td:nth-child(1), td:nth-child(2) > center > table[cellspacing="0"][cellpadding="0"] > tbody > tr:nth-child(1), table[cellspacing="0"][cellpadding="0"] > tbody > tr:nth-child(2) > td:nth-child(1), input[type="text"], body > center:nth-child(3), body > center:nth-child(6), center:nth-child(9), body > table[width="100%"], center:nth-child(15)
Rule: region
Description: Ensure all page content is contained by landmarks
Help: All page content should be contained by landmarks
Help URL: https://dequeuniversity.com/rules/axe/4.11/region?application=playwright


4) [SERIOUS] a[href$="mailto:SalesD@pnwx.com"]:nth-child(3)
Rule: target-size
Description: Ensure touch targets have sufficient size and space
Help: All touch targets must be 24px large, or leave sufficient space
Help URL: https://dequeuniversity.com/rules/axe/4.11/target-size?application=playwright


expect(received).toEqual(expected) // deep equality

- Expected  -   1
+ Received  + 337

- Array []
+ Array [
+   Object {
+     "description": "Ensure the document has a main landmark",
+     "help": "Document should have one main landmark",
+     "helpUrl": "https://dequeuniversity.com/rules/axe/4.11/landmark-one-main?application=playwright",
+     "id": "landmark-one-main",
+     "impact": "moderate",
+     "nodes": Array [
+       Object {
+         "all": Array [
+           Object {
+             "data": null,
+             "id": "page-has-main",
+             "impact": "moderate",
+             "message": "Document does not have a main landmark",
+             "relatedNodes": Array [],
+           },
+         ],
+         "any": Array [],
+         "failureSummary": "Fix all of the following:
+   Document does not have a main landmark",
+         "html": "<html>",
+         "impact": "moderate",
+         "none": Array [],
+         "target": Array [
+           "html",
+         ],
+       },
+     ],
+     "tags": Array [
+       "cat.semantics",
+       "best-practice",
+     ],
+   },
+   Object {
+     "description": "Ensure that the page, or at least one of its frames contains a level-one heading",
+     "help": "Page should contain a level-one heading",
+     "helpUrl": "https://dequeuniversity.com/rules/axe/4.11/page-has-heading-one?application=playwright",
+     "id": "page-has-heading-one",
+     "impact": "moderate",
+     "nodes": Array [
+       Object {
+         "all": Array [
+           Object {
+             "data": null,
+             "id": "page-has-heading-one",
+             "impact": "moderate",
+             "message": "Page must have a level-one heading",
+             "relatedNodes": Array [],
+           },
+         ],
+         "any": Array [],
+         "failureSummary": "Fix all of the following:
+   Page must have a level-one heading",
+         "html": "<html>",
+         "impact": "moderate",
+         "none": Array [],
+         "target": Array [
+           "html",
+         ],
+       },
+     ],
+     "tags": Array [
+       "cat.semantics",
+       "best-practice",
+     ],
+   },
+   Object {
+     "description": "Ensure all page content is contained by landmarks",
+     "help": "All page content should be contained by landmarks",
+     "helpUrl": "https://dequeuniversity.com/rules/axe/4.11/region?application=playwright",
+     "id": "region",
+     "impact": "moderate",
+     "nodes": Array [
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "isIframe": false,
+             },
+             "id": "region",
+             "impact": "moderate",
+             "message": "Some page content is not contained by landmarks",
+             "relatedNodes": Array [],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Some page content is not contained by landmarks",
+         "html": "<td><img src=\"/pnwx_ani.gif\" alt=\"Pacific Northwest X-Ray Inc.\"></td>",
+         "impact": "moderate",
+         "none": Array [],
+         "target": Array [
+           "body > center:nth-child(1) > table[cellspacing=\"0\"][cellpadding=\"0\"] > tbody > tr > td:nth-child(1)",
+         ],
+       },
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "isIframe": false,
+             },
+             "id": "region",
+             "impact": "moderate",
+             "message": "Some page content is not contained by landmarks",
+             "relatedNodes": Array [],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Some page content is not contained by landmarks",
+         "html": "<tr><td><img src=\"/Proto3UL.gif\"></td><td><img src=\"/Proto3UR.gif\"></td></tr>",
+         "impact": "moderate",
+         "none": Array [],
+         "target": Array [
+           "td:nth-child(2) > center > table[cellspacing=\"0\"][cellpadding=\"0\"] > tbody > tr:nth-child(1)",
+         ],
+       },
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "isIframe": false,
+             },
+             "id": "region",
+             "impact": "moderate",
+             "message": "Some page content is not contained by landmarks",
+             "relatedNodes": Array [],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Some page content is not contained by landmarks",
+         "html": "<td><img src=\"/Proto3LL.gif\"></td>",
+         "impact": "moderate",
+         "none": Array [],
+         "target": Array [
+           "table[cellspacing=\"0\"][cellpadding=\"0\"] > tbody > tr:nth-child(2) > td:nth-child(1)",
+         ],
+       },
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "isIframe": false,
+             },
+             "id": "region",
+             "impact": "moderate",
+             "message": "Some page content is not contained by landmarks",
+             "relatedNodes": Array [],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Some page content is not contained by landmarks",
+         "html": "<input type=\"text\" name=\"SearchWords\" size=\"20\" maxlength=\"75\" value=\"\">",
+         "impact": "moderate",
+         "none": Array [],
+         "target": Array [
+           "input[type=\"text\"]",
+         ],
+       },
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "isIframe": false,
+             },
+             "id": "region",
+             "impact": "moderate",
+             "message": "Some page content is not contained by landmarks",
+             "relatedNodes": Array [],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Some page content is not contained by landmarks",
+         "html": "<center><img usemap=\"#NavBar\" src=\"/Bar4Sky.gif\" border=\"0\"></center>",
+         "impact": "moderate",
+         "none": Array [],
+         "target": Array [
+           "body > center:nth-child(3)",
+         ],
+       },
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "isIframe": false,
+             },
+             "id": "region",
+             "impact": "moderate",
+             "message": "Some page content is not contained by landmarks",
+             "relatedNodes": Array [],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Some page content is not contained by landmarks",
+         "html": "<center>",
+         "impact": "moderate",
+         "none": Array [],
+         "target": Array [
+           "body > center:nth-child(6)",
+         ],
+       },
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "isIframe": false,
+             },
+             "id": "region",
+             "impact": "moderate",
+             "message": "Some page content is not contained by landmarks",
+             "relatedNodes": Array [],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Some page content is not contained by landmarks",
+         "html": "<center>",
+         "impact": "moderate",
+         "none": Array [],
+         "target": Array [
+           "center:nth-child(9)",
+         ],
+       },
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "isIframe": false,
+             },
+             "id": "region",
+             "impact": "moderate",
+             "message": "Some page content is not contained by landmarks",
+             "relatedNodes": Array [],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Some page content is not contained by landmarks",
+         "html": "<table border=\"0\" width=\"100%\">",
+         "impact": "moderate",
+         "none": Array [],
+         "target": Array [
+           "body > table[width=\"100%\"]",
+         ],
+       },
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "isIframe": false,
+             },
+             "id": "region",
+             "impact": "moderate",
+             "message": "Some page content is not contained by landmarks",
+             "relatedNodes": Array [],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Some page content is not contained by landmarks",
+         "html": "<center>",
+         "impact": "moderate",
+         "none": Array [],
+         "target": Array [
+           "center:nth-child(15)",
+         ],
+       },
+     ],
+     "tags": Array [
+       "cat.keyboard",
+       "best-practice",
+       "RGAAv4",
+       "RGAA-9.2.1",
+     ],
+   },
+   Object {
+     "description": "Ensure touch targets have sufficient size and space",
+     "help": "All touch targets must be 24px large, or leave sufficient space",
+     "helpUrl": "https://dequeuniversity.com/rules/axe/4.11/target-size?application=playwright",
+     "id": "target-size",
+     "impact": "serious",
+     "nodes": Array [
+       Object {
+         "all": Array [],
+         "any": Array [
+           Object {
+             "data": Object {
+               "height": 18,
+               "minSize": 24,
+               "width": 89.8,
+             },
+             "id": "target-size",
+             "impact": "serious",
+             "message": "Target has insufficient size (89.8px by 18px, should be at least 24px by 24px)",
+             "relatedNodes": Array [],
+           },
+           Object {
+             "data": Object {
+               "closestOffset": 8,
+               "minOffset": 24,
+             },
+             "id": "target-offset",
+             "impact": "serious",
+             "message": "Target has insufficient space to its closest neighbors. Safe clickable space has a diameter of 8px instead of at least 24px.",
+             "relatedNodes": Array [
+               Object {
+                 "html": "<a href=\"mailto:SalesD@pnwx.com\"><img src=\"/mail.gif\" border=\"0\"></a>",
+                 "target": Array [
+                   "a[href$=\"mailto:SalesD@pnwx.com\"]:nth-child(1)",
+                 ],
+               },
+             ],
+           },
+         ],
+         "failureSummary": "Fix any of the following:
+   Target has insufficient size (89.8px by 18px, should be at least 24px by 24px)
+   Target has insufficient space to its closest neighbors. Safe clickable space has a diameter of 8px instead of at least 24px.",
+         "html": "<a href=\"mailto:SalesD@pnwx.com\"><font face=\"Arial,Helvetica\" color=\"#000000\">E-Mail Sales</font></a>",
+         "impact": "serious",
+         "none": Array [],
+         "target": Array [
+           "a[href$=\"mailto:SalesD@pnwx.com\"]:nth-child(3)",
+         ],
+       },
+     ],
+     "tags": Array [
+       "cat.sensory-and-visual-cues",
+       "wcag22aa",
+       "wcag258",
+     ],
+   },
+ ]
```

# Test source

```ts
  326 |   tags: string[],
  327 |   results: any,
  328 |   metaExtra?: Record<string, unknown>,
  329 |   options?: A11yOptions
  330 | ) {
  331 |   ensureDir(REPORT_DIR);
  332 | 
  333 |   const normalizedName = normalizeLabel(reportName, "accessibility-report");
  334 |   const base = safeBaseName(normalizedName);
  335 |   const stamp = Date.now();
  336 | 
  337 |   const htmlFile = `${base}.html`;
  338 |   const jsonFile = `${base}.json`;
  339 | 
  340 |   // --- HTML report ---
  341 |   createHtmlReport({
  342 |     results,
  343 |     options: {
  344 |       reportFileName: htmlFile,
  345 |       outputDir: REPORT_DIR,
  346 |     },
  347 |   });
  348 | 
  349 |   const htmlPath = path.join(REPORT_DIR, htmlFile);
  350 | 
  351 |   // --- JSON report (raw axe results + metadata) ---
  352 |   const meta = {
  353 |     reportName: normalizedName,
  354 |     url: page.url(),
  355 |     scannedAt: new Date().toISOString(),
  356 |     tags,
  357 |     browserUserAgent: await page.evaluate(() => navigator.userAgent),
  358 |     ...metaExtra,
  359 |   };
  360 | 
  361 |   const jsonPath = path.join(REPORT_DIR, jsonFile);
  362 | 
  363 |   fs.writeFileSync(jsonPath, JSON.stringify({ meta, ...results }, null, 2), "utf8");
  364 | 
  365 |   // --- Rolling summary append ---
  366 |   appendSummary({
  367 |     reportName: normalizedName,
  368 |     url: meta.url,
  369 |     scannedAt: meta.scannedAt,
  370 |     tags,
  371 |     violations: countByImpact(results.violations),
  372 |     passes: results.passes?.length ?? 0,
  373 |     incomplete: results.incomplete?.length ?? 0,
  374 |     inapplicable: results.inapplicable?.length ?? 0,
  375 |     files: {
  376 |       html: htmlFile,
  377 |       json: jsonFile,
  378 |     },
  379 |   });
  380 | 
  381 |   const testInfo = options?.testInfo;
  382 |   const attachToReport = options?.attachToReport ?? !!testInfo;
  383 |   const screenshotsOnFailure = options?.screenshotsOnFailure ?? true;
  384 |   const maxElementScreenshots = options?.maxElementScreenshots ?? 10;
  385 |   const scopeSelector = (metaExtra?.scopeSelector as string | undefined) ?? undefined;
  386 | 
  387 |   if (testInfo && attachToReport) {
  388 |     await attachFileIfPossible(testInfo, "a11y: axe report (html)", htmlPath, "text/html");
  389 |     await attachFileIfPossible(testInfo, "a11y: axe results (json)", jsonPath, "application/json");
  390 |   }
  391 | 
  392 |   const failing = results.violations.filter((v: any) => FAIL_IMPACTS.includes(v.impact as AxeImpact));
  393 |   const warnings = results.violations.filter((v: any) => !FAIL_IMPACTS.includes(v.impact as AxeImpact));
  394 | 
  395 |   if (warnings.length > 0) {
  396 |     const warningMessage = formatViolations(warnings);
  397 |     console.warn(`Accessibility Warnings:\n${warningMessage}`);
  398 |   }
  399 | 
  400 |   if (failing.length > 0 && testInfo && attachToReport && screenshotsOnFailure) {
  401 |     const reportBase = `${base}-${stamp}`;
  402 | 
  403 |     await attachScopeScreenshot({ page, testInfo, reportBase, scopeSelector });
  404 | 
  405 |     await attachElementScreenshots({
  406 |       page,
  407 |       testInfo,
  408 |       reportBase,
  409 |       failingViolations: failing,
  410 |       scopeSelector,
  411 |       max: maxElementScreenshots,
  412 |     });
  413 | 
  414 |     await attachHighlightedPageScreenshot({
  415 |       page,
  416 |       testInfo,
  417 |       reportBase,
  418 |       failingViolations: failing,
  419 |       scopeSelector,
  420 |     });
  421 |   }
  422 | 
  423 |   if (failing.length > 0) {
  424 |     const failingMessage = formatViolations(failing);
  425 |     console.warn(`Accessibility Failures:\n${failingMessage}`);
> 426 |     expect(results.violations, failingMessage).toEqual([]);
      |                                                ^ Error: 
  427 |   }
  428 | 
  429 |   return results;
  430 | }
  431 | 
  432 | /**
  433 |  * Runs axe-core against the whole page (default behavior).
  434 |  */
  435 | export async function runAccessibilityCheck(
  436 |   page: Page,
  437 |   reportName: unknown = "accessibility-report",
  438 |   options?: A11yOptions
  439 | ) {
  440 |   const tags = options?.tags ?? [
  441 |     'wcag22aa',    // Covers ALL rules for 2.0, 2.1, and 2.2 at Level A & AA
  442 |     'wcag21aaa',   // Covers the specific AAA rules available in axe-core
  443 |     'best-practice' // Highly recommended: catches UX issues not strictly in WCAG
  444 |   ];
  445 |   const results = await new AxeBuilder({ page }).withTags(tags).analyze();
  446 |   return reportAndAssertA11y(page, reportName, tags, results, undefined, options);
  447 | }
  448 | 
  449 | /**
  450 |  * Runs axe-core ONLY within a visible dialog (or any element subtree you target).
  451 |  */
  452 | export async function runDialogAccessibilityCheck(
  453 |   page: Page,
  454 |   dialogIdOrSelector: string,
  455 |   reportName?: unknown,
  456 |   options?: A11yOptions
  457 | ) {
  458 |   const tags = options?.tags ?? [
  459 |     'wcag22aa',    // Covers ALL rules for 2.0, 2.1, and 2.2 at Level A & AA
  460 |     'wcag21aaa',   // Covers the specific AAA rules available in axe-core
  461 |     'best-practice' // Highly recommended: catches UX issues not strictly in WCAG
  462 |   ];
  463 |   const cssSelector = toCssSelector(dialogIdOrSelector);
  464 |   const visibleSelector = toPlaywrightVisibleSelector(dialogIdOrSelector);
  465 |   const timeout = options?.scopeVisibleTimeoutMs ?? 30_000;
  466 | 
  467 |   await expect(page.locator(visibleSelector)).toBeVisible({ timeout });
  468 | 
  469 |   const results = await new AxeBuilder({ page }).withTags(tags).include(cssSelector).analyze();
  470 | 
  471 |   const finalReportName =
  472 |     reportName ?? `${safeBaseName(normalizeLabel(dialogIdOrSelector, "scope"))}-accessibility-scope-report`;
  473 | 
  474 |   return reportAndAssertA11y(
  475 |     page,
  476 |     finalReportName,
  477 |     tags,
  478 |     results,
  479 |     { scopeSelector: cssSelector },
  480 |     options
  481 |   );
  482 | }
  483 | 
  484 | /**
  485 |  * Compatibility helper:
  486 |  * Your IBM accessibility-checker version needs close() to flush CSV/XLSX.
  487 |  * Axe-core does NOT — but exporting this lets your spec call it safely anyway.
  488 |  */
  489 | export async function closeAccessibilityChecker() {
  490 |   // no-op for axe-core
  491 | }
  492 | 
  493 | function formatViolations(violations: any[]) {
  494 |   return violations
  495 |     .map((violation: any, index: number) => {
  496 |       const selectors = (violation.nodes ?? [])
  497 |         .flatMap((node: any) => (Array.isArray(node?.target) ? node.target : []))
  498 |         .join(", ");
  499 | 
  500 |       return `
  501 | ${index + 1}) [${String(violation.impact || "").toUpperCase()}] ${selectors}
  502 | Rule: ${violation.id}
  503 | Description: ${violation.description}
  504 | Help: ${violation.help}
  505 | Help URL: ${violation.helpUrl}
  506 | `;
  507 |     })
  508 |     .join("\n");
  509 | }
  510 | 
```